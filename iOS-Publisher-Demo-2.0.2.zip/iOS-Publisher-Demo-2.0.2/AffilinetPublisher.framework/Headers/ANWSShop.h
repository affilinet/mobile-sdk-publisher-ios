//
//  ANWSShop.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANWSProgram.h"
#import "ANWSShopLogo.h"
#import "ANWSItem.h"

@interface ANWSShop : NSObject <ANWSItem>

@property (nonatomic, assign) NSInteger shopId;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *link;
@property (nonatomic, assign) NSInteger productCount;
@property (nonatomic, strong) NSDate *lastUpdate;
@property (nonatomic, strong) ANWSProgram *program;
@property (nonatomic, strong) NSArray *logos;

@end
