//
//  ANContainerAd.h
//  AffilinetSDK
//
//  Created by João Santos on 25/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAd.h"

@interface ANContainerAd : ANAd

@property (nonatomic, strong) NSString *pcid;
@property (nonatomic, strong) NSString *subid;

@property (nonatomic, strong) NSString *uid DEPRECATED_MSG_ATTRIBUTE("uid is deprecated, please use pcid and subid instead.");

@end
