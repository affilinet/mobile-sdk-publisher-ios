//
//  ANWebserviceOperation.h
//  AffilinetSDK
//
//  Created by João Santos on 16/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANOperation.h"
#import "ANWebserviceRequest.h"
#import "ANWebserviceResponse.h"

@interface ANWebserviceOperation : ANOperation

@property (nonatomic, strong, readonly) NSArray <ANRequest*> *requests;
@property (copy) void(^onFinishOperation)(void);
@property (copy) void(^onFailOperation)(NSError *);
@property (copy) void(^onRequestCompletion)(ANWebserviceRequest *request, ANWebserviceResponse *response);

-(id) initWithSession:(ANSession *)session andRequests:(NSArray *) requests;

@end
