//
//  ANGetProductsVC.m
//  AffilinetPublisherSDKDemo
//
//  Created by João Santos on 17/01/14.
//  Copyright (c) 2014 João Santos. All rights reserved.
//

#import "ANGetProductsVC.h"
#import <AffilinetPublisher/AffilinetPublisher.h>

@interface ANGetProductsVC ()

@end

@implementation ANGetProductsVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        ANGetProductsRequest *getProductsReq = [[ANGetProductsRequest alloc] initWithSession:[ANSession sharedInstance]];
        
        getProductsReq.productIds = @[@"493822602", @"526068620", @"437092183"];
        
//        [getProductsReq addShopLogoScale:Logo120];
//        [getProductsReq addShopLogoScale:Logo50];
//        [getProductsReq addShopLogoScale:NoLogo];
//        
//        [getProductsReq addProductImageScale:OriginalImage];
//        [getProductsReq addProductImageScale:Image30];
//        [getProductsReq addProductImageScale:Image60];
        
        [[ANSession sharedInstance] executeRequests:@[getProductsReq]];
        
        [[ANSession sharedInstance] setOnRequestResponse:^(ANRequest *request, ANRequestResponse *response) {
            if(response.error != nil) {
                NSLog(@"Request %@ finished with error %@", request, response.error);
            }
            else {
                NSLog(@"Request %@ finished with response %@", request, response);
            }
        }];
        
        [[ANSession sharedInstance] setOnRequestsFinished:^{
            NSLog(@"Requests Finished");
        }];
        
        [[ANSession sharedInstance] setOnRequestsError:^(NSError *error) {
            NSLog(@"Requests finished with error: %@", error);
        }];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
