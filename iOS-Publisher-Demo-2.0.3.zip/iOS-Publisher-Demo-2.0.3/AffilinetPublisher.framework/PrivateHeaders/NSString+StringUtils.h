//
//  NSString+StringUtils.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (StringUtils)

-(NSString *) stringByRemovingLastChar;
-(NSString *) stringByRemovingFirstChar;
-(NSString *) urlEncodeUsingEncoding:(NSStringEncoding)encoding;
-(NSString *) getFirstMatchWithPattern:(NSString *) pattern;

+(NSDate *) dateFromAffilinetTimestampFormat:(NSString *) date;

@end
