//
//  ANAdDisplayView.h
//  AffilinetSDK
//
//  Created by João Santos on 25/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ANSession.h"
#import "ANAd.h"

@class ANAdDisplayView;

@protocol ANAdDisplayViewDelegate <NSObject>

- (void) adDisplayViewDidFinishLoading:(ANAdDisplayView *) adDisplayView;
- (void) adDisplayView:(ANAdDisplayView *) adDisplayView didFailLoading:(NSError *) error;

@end

@interface ANAdDisplayView : UIView

-(id) initWithFrame:(CGRect) frame andAd:(ANAd *) ad;

@property (nonatomic, assign) id<ANAdDisplayViewDelegate> delegate;

@end
