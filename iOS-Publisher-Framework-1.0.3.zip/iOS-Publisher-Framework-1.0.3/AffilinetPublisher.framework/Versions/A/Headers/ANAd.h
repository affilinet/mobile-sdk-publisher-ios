//
//  ANAd.h
//  AffilinetSDK
//
//  Created by João Santos on 25/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ANRequest.h"

typedef enum {
    ANFullSizeBanner,
    ANMediumRectangle,
    ANWideSkyscrapper,
    ANSkyscrapper,
    ANLeaderboard
} ANAdSize;

@interface ANAd : ANRequest

@property (nonatomic, assign) ANAdSize size;

-(NSString *) adHtml;
-(CGSize) getCGSize;

+(NSString *) getHNBForAdSize:(ANAdSize) adSize;
+(NSString *) getBNBForAdSize:(ANAdSize) adSize;

@end
