//
//  ANWSProgram.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANWSProgram : NSObject

@property (nonatomic, assign) NSInteger programId;
@property (nonatomic, strong) NSString *title;

@end
