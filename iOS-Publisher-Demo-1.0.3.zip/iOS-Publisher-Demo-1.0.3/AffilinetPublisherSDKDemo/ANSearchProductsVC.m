//
//  ANSearchProductsVC.m
//  AffilinetPublisherSDKDemo
//
//  Created by João Santos on 20/01/14.
//  Copyright (c) 2014 João Santos. All rights reserved.
//

#import "ANSearchProductsVC.h"
#import <AffilinetPublisher/AffilinetPublisher.h>

@implementation ANSearchProductsVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        ANSearchProductsRequest *searchReq = [[ANSearchProductsRequest alloc] initWithSession:[ANSession sharedInstance]];
        
        searchReq.shopIds = @[@"0"];
        searchReq.shopIdMode = Include;
        searchReq.categoryIds = @[@"33388558"];
        searchReq.useAffilinetCategories = NO;
        searchReq.excludeSubCategories = NO;
        searchReq.withImageOnly = YES;
        [searchReq addProductImageScale:OriginalImage];
        [searchReq addShopLogoScale:Logo120];
        searchReq.maximumPrice = 100.5;
        searchReq.minimumPrice = 0.5;
        searchReq.sortBy = Name;
        searchReq.sortOrder = Ascending;
        
        [[ANSession sharedInstance] executeRequests:@[searchReq]];
        
        [[ANSession sharedInstance] setOnRequestResponse:^(ANRequest *request, ANRequestResponse *response) {
            if(response.error != nil) {
                NSLog(@"Request %@ finished with error %@", request, response.error);
            }
            else {
                NSLog(@"Request %@ finished with response %@", request, response);
            }
        }];
        
        [[ANSession sharedInstance] setOnRequestsFinished:^{
            NSLog(@"Requests Finished");
        }];
        
        [[ANSession sharedInstance] setOnRequestsError:^(NSError *error) {
            NSLog(@"Requests finished with error: %@", error);
        }];
    }
    return self;
}

@end
