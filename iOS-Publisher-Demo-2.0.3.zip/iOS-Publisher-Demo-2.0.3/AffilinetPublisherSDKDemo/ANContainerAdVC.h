//
//  ANContainerAdVC.h
//  AffilinetPublisherSDKDemo
//
//  Created by João Santos on 25/11/13.
//  Copyright (c) 2013 João Santos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ANContainerAdVC : UIViewController

@end
