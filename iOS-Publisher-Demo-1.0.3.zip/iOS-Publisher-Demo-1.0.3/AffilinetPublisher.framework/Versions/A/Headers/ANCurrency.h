//
//  Currency.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    ANCurrencyCodeEUR,
    ANCurrencyCodeUSD,
    ANCurrencyCodeBGN,
    ANCurrencyCodeDKK,
    ANCurrencyCodeGBP,
    ANCurrencyCodeLTL,
    ANCurrencyCodeCAD,
    ANCurrencyCodeCHF
} ANCurrencyCode;

@interface ANCurrency : NSObject

-(id) initWithCurrencyCode:(ANCurrencyCode) currencyCode;
-(id) initWithStringCode:(NSString *) code;
-(NSString *) stringValue;

@end
