//
//  GetCategoryListVC.h
//  AffilinetPublisherSDKDemo
//
//  Created by João Santos on 16/01/14.
//  Copyright (c) 2014 João Santos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ANGetCategoryListVC : UIViewController

@end
