//
//  AppDelegate.m
//  AffilinetPublisherSDKDemo
//
//  Created by João Santos on 25/11/13.
//  Copyright (c) 2013 João Santos. All rights reserved.
//

#import "AppDelegate.h"
#import "ANContainerAdVC.h"
#import "ANGetCategoryListVC.h"
#import "ANGetShopListVC.h"
#import "ANGetProductsVC.h"
#import "ANSearchProductsVC.h"
#import <AffilinetPublisher/AffilinetPublisher.h>

@interface AppDelegate ()

@property (nonatomic, strong) ANPublisherAccount *pubAccount;

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
#warning TODO: add your publisher-id
    self.pubAccount = [ANPublisherAccount publisherAccountWithID:@1/*{PUBLISHER-ID}*/];
#warning TODO: add your product data webservice password
    self.pubAccount.webServicePassword = @""/*{PRODUCT-DATA-WEBSERVICE-PASSWORD}*/;
#warning TODO: select affilinet platform which aligns with your publisher account
    [[ANSession sharedInstance] openWithAccount:self.pubAccount andCountryCode:ANCountryCodeDE];
    
    ANContainerAdVC *adViewController = [[ANContainerAdVC alloc] initWithNibName:nil bundle:nil];
    UINavigationController *adNavigationController = [[UINavigationController alloc] init];
    adNavigationController.viewControllers = @[adViewController];
    adNavigationController.tabBarItem.title = @"Ads";

    ANGetCategoryListVC *categoryViewController = [[ANGetCategoryListVC alloc] initWithNibName:nil bundle:nil];
    UINavigationController *categoryNavigationController = [[UINavigationController alloc] init];
    categoryNavigationController.viewControllers = @[categoryViewController];
    categoryNavigationController.tabBarItem.title = @"Categories";

    ANGetShopListVC *shopListViewController = [[ANGetShopListVC alloc] initWithNibName:nil bundle:nil];
    UINavigationController *shopListNavigationController = [[UINavigationController alloc] init];
    shopListNavigationController.viewControllers = @[shopListViewController];
    shopListNavigationController.tabBarItem.title = @"Shops";

    ANGetProductsVC *productsViewController = [[ANGetProductsVC alloc] initWithNibName:nil bundle:nil];
    UINavigationController *productsNavigationController = [[UINavigationController alloc] init];
    productsNavigationController.viewControllers = @[productsViewController];
    productsNavigationController.tabBarItem.title = @"Products";

    ANSearchProductsVC *searchProductsViewController = [[ANSearchProductsVC alloc] initWithNibName:nil bundle:nil];
    UINavigationController *searchNavigationController = [[UINavigationController alloc] init];
    searchNavigationController.viewControllers = @[searchProductsViewController];
    searchNavigationController.tabBarItem.title = @"Search";

    UITabBarController * tabBarController = [[UITabBarController alloc] init];
    tabBarController.viewControllers = @[adNavigationController, categoryNavigationController, shopListNavigationController, productsNavigationController, searchNavigationController];
    [self.window setRootViewController:tabBarController];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
