//
//  ANContainerAdVC.m
//  AffilinetPublisherSDKDemo
//
//  Created by João Santos on 25/11/13.
//  Copyright (c) 2013 João Santos. All rights reserved.
//

#import "ANContainerAdVC.h"
#import <AffilinetPublisher/AffilinetPublisher.h>

@interface ANContainerAdVC () <ANAdDisplayViewDelegate>

@property (nonatomic, strong) ANContainerAd *containerAd;
@property (nonatomic, strong) ANAdDisplayView *adDisplayView;

@end

@implementation ANContainerAdVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.containerAd = [[ANContainerAd alloc] initWithSession:[ANSession sharedInstance]];
        self.containerAd.pcid = @"0000028b-13ea-1168-1dea-3bc864ac153a";
        //self.containerAd.subid = @"abc123";
        
        self.adDisplayView = [[ANAdDisplayView alloc] initWithFrame:(CGRect){{0,0}, self.view.frame.size} andAd:self.containerAd];
        self.adDisplayView.delegate = self;
        [self.view addSubview:self.adDisplayView];
    }
    return self;
}

#pragma mark -
#pragma mark ANAdDisplayViewDelegate methods

-(void) adDisplayViewDidFinishLoading:(ANAdDisplayView *)adDisplayView {
    NSLog(@"Did Finish Loading Ad View");
}

-(void) adDisplayView:(ANAdDisplayView *)adDisplayView didFailLoading:(NSError *)error {
    NSLog(@"Did Fail Loading Ad View: %@", error);
}

@end
