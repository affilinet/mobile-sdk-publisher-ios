//
//  HTMLBuilder.h
//  AffilinetSDK
//
//  Created by Joao Santos on 23/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GDataXMLNode.h"

@interface ANHTMLBuilder : NSOperation

-(void) appendHtml:(NSString *) string;
-(NSString *) html;

@end
