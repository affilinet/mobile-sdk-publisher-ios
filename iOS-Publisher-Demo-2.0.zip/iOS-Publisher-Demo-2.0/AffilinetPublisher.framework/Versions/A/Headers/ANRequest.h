//
//  ANRequest.h
//  AffilinetSDK
//
//  Created by Joao Santos on 23/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANSession.h"

@class ANSession;
@class ANRequestResponse;

typedef enum {
    ANRequestProtocolHTTP,
    ANRequestProtocolHTTPS
} ANRequestProtocol;

@interface ANRequest : NSObject

@property (nonatomic, strong, readonly) ANSession *session;
@property (nonatomic, assign) ANRequestProtocol protocol;

//@property (copy) void(^onRequestResponse)(ANRequest *, ANRequestResponse *);
//@property (copy) void(^onRequestError)(NSError *);
@property (copy) void(^onRequestFinished)(ANRequest *request, ANRequestResponse *response);

-(id) initWithSession:(ANSession *) session;
-(NSString *) protocolAsString;

@end
