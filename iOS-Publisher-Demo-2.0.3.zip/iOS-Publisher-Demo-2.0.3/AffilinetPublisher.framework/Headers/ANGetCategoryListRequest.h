//
//  ANGetCategoryListRequest.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANWebserviceRequest.h"

@interface ANGetCategoryListRequest : ANWebserviceRequest

@property (nonatomic, strong) NSString *shopId;

@end
