//
//  GetCategoryListVC.m
//  AffilinetPublisherSDKDemo
//
//  Created by João Santos on 16/01/14.
//  Copyright (c) 2014 João Santos. All rights reserved.
//

#import "ANGetCategoryListVC.h"
#import <AffilinetPublisher/AffilinetPublisher.h>

@interface ANGetCategoryListVC ()

@end

@implementation ANGetCategoryListVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        ANGetCategoryListRequest *getCLRequest1 = [[ANGetCategoryListRequest alloc] initWithSession:[ANSession sharedInstance]];
        getCLRequest1.shopId = @"0";
        
        ANGetCategoryListRequest *getCLRequest2 = [[ANGetCategoryListRequest alloc] initWithSession:[ANSession sharedInstance]];
        getCLRequest1.shopId = @"0";
        
        ANGetCategoryListRequest *getCLRequest3 = [[ANGetCategoryListRequest alloc] initWithSession:[ANSession sharedInstance]];
        getCLRequest1.shopId = @"0";
        
        ANGetCategoryListRequest *getCLRequest4 = [[ANGetCategoryListRequest alloc] initWithSession:[ANSession sharedInstance]];
        getCLRequest1.shopId = @"0";
        
        
        [[ANSession sharedInstance] executeRequests:@[getCLRequest1,getCLRequest2,getCLRequest3,getCLRequest4]];
        
        [[ANSession sharedInstance] setOnRequestResponse:^(ANRequest *request, ANRequestResponse *response) {
            if(response.error != nil) {
                NSLog(@"Request %@ finished with error %@", request, response.error);
            }
            else {
                NSLog(@"Request %@ finished with response %@", request, response);
            }
        }];
        
        [[ANSession sharedInstance] setOnRequestsFinished:^{
            NSLog(@"Requests Finished");
        }];
        
        [[ANSession sharedInstance] setOnRequestsError:^(NSError *error) {
            NSLog(@"Requests finished with error: %@", error);
        }];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
