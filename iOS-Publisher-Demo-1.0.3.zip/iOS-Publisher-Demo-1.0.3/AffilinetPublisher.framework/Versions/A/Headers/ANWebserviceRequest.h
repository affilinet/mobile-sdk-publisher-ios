//
//  ANWebserviceRequest.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANRequest.h"
#import "ANWebserviceResponse.h"

@class ANWebserviceRequest;

@protocol ANWebserviceRequestDelegate <NSObject>

-(void) webserviceRequest:(ANWebserviceRequest *) request withResponse:(ANWebserviceResponse *)response;

@end

@interface ANWebserviceRequest : ANRequest

@property (nonatomic, assign) NSUInteger currentPage;
@property (nonatomic, assign) NSUInteger pageSize;
@property (nonatomic, assign) id<ANWebserviceRequestDelegate> delegate;
@property (nonatomic, strong, readonly) NSURL *requestURL;

@end
