//
//  ANWSProductProperty.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANWSProductProperty : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *value;

@end
