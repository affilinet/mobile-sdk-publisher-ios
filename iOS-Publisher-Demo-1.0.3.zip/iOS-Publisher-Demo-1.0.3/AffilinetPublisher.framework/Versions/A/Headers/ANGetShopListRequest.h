//
//  ANGetShopListRequest.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//
#import "ANWebserviceRequest.h"
#import "ANWSShopLogoScale.h"

@interface ANGetShopListRequest : ANWebserviceRequest

@property (nonatomic, strong) NSString *query;
@property (nonatomic, strong) NSDate *updatedAfter;
@property (nonatomic, assign) ANWSShopLogoScale logoScale;

@end
