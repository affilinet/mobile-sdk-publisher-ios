//
//  ANWSProductImageScale.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

typedef enum {
    OriginalImage,
    Image30,
    Image60,
    Image90,
    Image120,
    Image180,
    NoImage
} ANWSProductImageScale;
