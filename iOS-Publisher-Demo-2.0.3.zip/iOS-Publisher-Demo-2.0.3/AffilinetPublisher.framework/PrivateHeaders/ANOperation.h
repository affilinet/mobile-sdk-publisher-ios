//
//  ANOperation.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANSession.h"

@interface ANOperation : NSOperation


-(id) initWithSession:(ANSession *) session;
-(void) execute;

@end
